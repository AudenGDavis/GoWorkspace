package main

import "linePhysics"

func main() {

}
