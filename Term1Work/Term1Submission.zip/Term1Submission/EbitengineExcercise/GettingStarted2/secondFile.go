package main

type TestStruct struct{}
