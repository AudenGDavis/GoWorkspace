package main

import "fmt"

func main() {
	fmt.Println("")
	fmt.Println("            ___")
	fmt.Println("         🌸＞  フ")
	fmt.Println("        |  _  _ l")
	fmt.Println("       /` ミ__x_")
	fmt.Println("      /        |")
	fmt.Println("     /   ヽ    ﾉ")
	fmt.Println("     │   |  |  |")
	fmt.Println(" ／￣|   |  |  |")
	fmt.Println(" | (￣ヽ__ヽ_)__)")
	fmt.Println(" ＼二つ")
	fmt.Println("")
}
